/** Automatically generated file. DO NOT MODIFY */
package com.hectorone.multismssender;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}